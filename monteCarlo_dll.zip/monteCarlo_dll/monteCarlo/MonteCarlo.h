#ifndef MONTECARLO_H
#define MONTECARLO_H

#include <math.h>
#include "MathLib.h"

class MonteCarlo1Asset {
public:
	static MonteCarlo1Asset* Instance();

	void setSpotVal(double spotVal) { m_spotVal = spotVal; }
	void setVol(double vol) { m_vol = vol; }
	void setDiv(double div) { m_div = log(1.0+div); }
	void setIr(double ir) { m_ir = log(1.0+ir); }
	void setDt(double dt) { m_dt = dt / 365.25; }

	double getSpotVal() { return m_spotVal; }
	double getVol() { return m_vol; }
	double getDiv() { return m_div; }
	double getIr() { return m_ir; }
	double getDt() { return m_dt; }

	double simulate();			/* simulate one step */
			
private:
	static MonteCarlo1Asset* _instance;
	MonteCarlo1Asset() {}

	double		m_spotVal;		/* (I) spot value of asset */
	double		m_vol;			/* (I) annual volatility of asset */
	double		m_div;			/* (I) dividend yield of asset (same basis as interest rate) */
	double		m_ir;			/* (I) interest rate actual/365.25 basis, annual compounded */
	double		m_dt;			/* (I) time step in days */
};

int __stdcall MonteCarlo(double spotVal, double vol, double div, double ir, double dt);
double __stdcall MCSimulate();

#endif

	
