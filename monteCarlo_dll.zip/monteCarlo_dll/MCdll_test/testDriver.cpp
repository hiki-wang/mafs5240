#include "../monteCarlo/MonteCarlo.h"
#include <iostream>

using namespace std;

int main() {

	long	steps;

	cout << endl;
	cout << "Enter number of Steps: ";
	cin >> steps;

	MonteCarlo(100.0,0.3,0.01,0.1,1.0);

	cout << "Step\t" << 0 << "\t" << 100.0 << endl;
	for (long i=1; i<=steps; i++) {
		cout << "Step\t" << i << "\t" << MCSimulate() << endl;
	}

	return 1;
}