#include "MonteCarlo.h"

int main() {
	return 1;
}